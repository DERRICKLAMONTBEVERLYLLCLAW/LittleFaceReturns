# LAPD CPRA Follow-Up & Escalation (Template)

Re: Request for copies/confirmations of relevant reports and active investigation status.

Key facts to reference:
- Little Face stolen (March, two-week window), before deliberate arson near RFK Park (Wilshire & Alexandria).
- Separate report: May 22, 2023 hit-and-run (dog 'Perfect') near W 8th & Irolo.
- Public petition link: [insert live Change.org link]
- Attached: flyer, declaration, exhibits, QR poster.

Please provide acknowledgement within 10 days per Gov. Code §6253(c).
