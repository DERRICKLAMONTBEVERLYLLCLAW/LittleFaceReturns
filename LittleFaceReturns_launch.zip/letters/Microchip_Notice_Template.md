# Microchip Theft Notice (Template)

To: East Valley Animal Shelter & Microchip Registry
Subject: Flag chip as STOLEN for 'Little Face'

Little Face was stolen in March (two‑week window), and the registration packet was lost due to a subsequent arson attack.
Please flag the chip as **STOLEN**, associate contact info below, and alert all LA shelters and vets.

Contact:
Derrick LaMont Beverly
(323) 459-9585
derniercrilamont@yahoo.com
