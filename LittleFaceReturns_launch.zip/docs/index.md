---
title: Bring Little Face Home
---

# Bring Little Face Home

**Stolen:** March (two‑week window), **before a deliberate arson** destroyed Derrick's tent near **RFK Park**.  
**Area:** Wilshire & Alexandria; walk up from 8th & Mariposa.  

## How to Help
- Share and sign the petition (link will be updated when live).
- Post the flyer in Koreatown / Mid‑Wilshire.
- Send tips (anonymous form coming soon).

### Files
- Print‑safe flyer in **/flyers/**
- LAPD letters in **/letters/**
- Media kit in **/press/**
