# Phone Scripts

## LAPD Records / Olympic Division
Hi, my name is Derrick LaMont Beverly. I'm calling to follow up on two linked incidents:
1) March theft of my dog 'Little Face' within a two-week window, followed by a deliberate arson near RFK Park.
2) May 22, 2023 hit-and-run that killed my dog 'Perfect'.

I have a public petition and evidence archive. Who can confirm receipt, provide report numbers, and current status?

## Media / News Desks
Hi, I'm requesting coverage of a Koreatown theft-and-arson case affecting an unhoused Angeleno.
My dog 'Little Face' was stolen in March; minutes later my tent was set on fire. I have documentation, photos, and a petition link.
Is there a reporter available today?
